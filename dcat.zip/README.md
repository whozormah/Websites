# DunniceCateringSite
Dunnice - HTML, Pure CSS and Vanilla JS
Learning how to use git and Github
